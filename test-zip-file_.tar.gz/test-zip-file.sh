#!/bin/bash

echo "unzipped and test complete"
